//Nomes dos funcionários
let participantes = ("Aline", "Pé de rodo", "Juarez", "Lucas Reis","Ana Clara", "Miguel", ""
)